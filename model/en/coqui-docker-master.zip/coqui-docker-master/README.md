# Coqui Docker

Docker images for [Coqui AI](https://coqui.ai/) projects.

## Available Images

* [synesthesiam/coqui-tts](coqui-tts) for [Coqui TTS](https://github.com/coqui-ai/TTS)
    * Use [tts](coqui-tts/tts) and [tts-server](coqui-tts/tts-server) scripts
    * Use [tts-train](coqui-tts/tts-train) for training
